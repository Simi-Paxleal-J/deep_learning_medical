# deep_learning_works
Code to accompany "You can probably use deep learning even if your data isn't that big" blog post
